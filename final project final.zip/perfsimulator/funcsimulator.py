import os
import re
import argparse


class IMEM(object):
    def __init__(self, iodir):
        self.size = pow(2, 16)  # Can hold a maximum of 2^16 instructions.
        self.filepath = os.path.abspath(os.path.join(iodir, "Code.asm"))
        self.instructions = []

        try:
            with open(self.filepath, "r") as insf:
                self.instructions = [ins.strip() for ins in insf.readlines()]
            print("IMEM - Instructions loaded from file:", self.filepath)
            print("IMEM - Instructions:", self.instructions)
        except:
            print("IMEM - ERROR: Couldn't open file in path:", self.filepath)

    def Read(self, idx):  # Use this to read from IMEM.
        if idx < self.size:
            return self.instructions[idx]
        else:
            print(
                "IMEM - ERROR: Invalid memory access at index: ",
                idx,
                " with memory size: ",
                self.size,
            )


class DMEM(object):
    # Word addressible - each address contains 32 bits.
    def __init__(self, name, iodir, addressLen):
        self.name = name
        self.size = pow(2, addressLen)
        self.min_value = -pow(2, 31)
        self.max_value = pow(2, 31) - 1
        self.ipfilepath = os.path.abspath(os.path.join(iodir, name + ".txt"))
        self.opfilepath = os.path.abspath(os.path.join(iodir, name + "OP.txt"))
        self.data = []

        try:
            with open(self.ipfilepath, "r") as ipf:
                self.data = [int(line.strip()) for line in ipf.readlines()]
            print(self.name, "- Data loaded from file:", self.ipfilepath)
            # print(self.name, "- Data:", self.data)
            self.data.extend([0x0 for i in range(self.size - len(self.data))])
        except:
            print(
                self.name, "- ERROR: Couldn't open input file in path:", self.ipfilepath
            )

    def Read(self, idx):  # Use this to read from DMEM.
        if idx < self.size:
            # Read data at specific address
            return self.data[idx]
        else:
            # Error handling
            print(
                "DMEM - ERROR: Invalid memory access at index: ",
                idx,
                " with memory size: ",
                self.size,
            )

    def Write(self, idx, val):  # Use this to write into DMEM.
        if idx < self.size and (self.min_value < val < self.max_value):
            # Check index and value
            # If the target address OK and the number of value in range, write the data
            self.data[idx] = val
        else:
            # Error handling, print information
            print(
                "DMEM - ERROR: Invalid memory write at index: ",
                idx,
                " with value: ",
                val,
            )

    def dump(self):
        try:
            with open(self.opfilepath, "w") as opf:
                lines = [str(data) + "\n" for data in self.data]
                opf.writelines(lines)
            print(self.name, "- Dumped data into output file in path:", self.opfilepath)
        except:
            print(
                self.name,
                "- ERROR: Couldn't open output file in path:",
                self.opfilepath,
            )


class RegisterFile(object):
    def __init__(self, name, count, length=1, size=32):
        self.name = name
        self.reg_count = count
        self.vec_length = length  # Number of 32 bit words in a register.
        self.reg_bits = size
        self.min_value = -pow(2, self.reg_bits - 1)
        self.max_value = pow(2, self.reg_bits - 1) - 1
        self.registers = [
            [0x0 for e in range(self.vec_length)] for r in range(self.reg_count)
        ]  # list of lists of integers

    def Read(self, idx):
        if idx < self.reg_count:
            # Read data at specific index of register
            return self.registers[idx]
        else:
            # Error handling
            print(
                "RF - ERROR: Invalid register read at index: ",
                idx,
                " with size: ",
                self.reg_bits,
            )

    def Write(self, idx, val: list):
        if idx < self.reg_count and all(
            self.min_value <= x <= self.max_value for x in val
        ):
            # Write data at specific index of register
            self.registers[idx] = val
        else:
            # Error handling
            print(
                "RF - ERROR: Invalid register write at index: ",
                idx,
                " with size: ",
                self.reg_bits,
            )

    def dump(self, iodir):
        opfilepath = os.path.abspath(os.path.join(iodir, self.name + ".txt"))
        try:
            with open(opfilepath, "w") as opf:
                row_format = "{:<13}" * self.vec_length
                lines = [
                    row_format.format(*[str(i) for i in range(self.vec_length)]) + "\n",
                    "-" * (self.vec_length * 13) + "\n",
                ]
                lines += [
                    row_format.format(*[str(val) for val in data]) + "\n"
                    for data in self.registers
                ]
                opf.writelines(lines)
            print(self.name, "- Dumped data into output file in path:", opfilepath)
        except:
            print(self.name, "- ERROR: Couldn't open output file in path:", opfilepath)


class Core:
    def __init__(self, imem, sdmem, vdmem):
        self.IMEM = imem
        self.SDMEM = sdmem
        self.VDMEM = vdmem

        self.RFs = {"SRF": RegisterFile("SRF", 8), "VRF": RegisterFile("VRF", 8, 64)}

        # Vector Mask Register
        # 1 Vector Mask Register also known as the Flag Register. Contains 64 1 bit values.
        self.VMR = [0x1 for e in range(64)]

        # Vector Length Register
        # 1 Vector Length Register of size 32 bits to contain the number of vector element
        self.VLR = RegisterFile("VLR", 1, 1, 32)

    #        self.RFs.update(VMR)
    #        self.RFs.update(VLR)

    def run(self):
        PC = 0
        while True:
            # Fetch instruction at PC
            ins = self.IMEM.Read(PC)
            ins_split = ins.split()
            #print("!!!!!", ins)

            #############Start VMR operations##################

            # Implement "CVM" instruction
            if ins == "CVM":
                self.VMR = [0x1 for e in range(64)]

            # Implement "POP" instruction
            if "POP" in ins:
                # Count the number of 1s in VMR
                count = 0
                if self.VMR:
                    count = self.VMR.count(1)
                    # Then store the scalar value in SR1.
                    self.RFs["SRF"].Write(int(ins.split("SR")[1]), [count])

            # Implement "S__VV"
            # Regular pattern of S__VV instructions
            SVV_pattern = r".*S(EQ|NE|GT|LT|GE|LE){1}VV.*"
            if re.match(SVV_pattern, ins):
                ins_split = ins.split()
                vec1 = self.RFs["VRF"].Read(int(ins_split[1].split("VR")[1]))
                vec2 = self.RFs["VRF"].Read(int(ins_split[2].split("VR")[1]))
                # new is for new value of VMR
                new = [0x1 for e in range(64)]

                def compare(OP, v1, v2):
                    if OP == "SEQVV":
                        return v1 == v2
                    if OP == "SNEVV":
                        return v1 != v2
                    if OP == "SGTVV":
                        return v1 > v2
                    if OP == "SLTVV":
                        return v1 < v2
                    if OP == "SGEVV":
                        return v1 >= v2
                    if OP == "SLEVV":
                        return v1 <= v2

                # Evaluate the comparison
                for i in range(len(vec1)):
                    if compare(ins_split[0], vec1[i], vec2[i]):
                        new[i] = 1
                    else:
                        new[i] = 0

                # Write back to VMR
                self.VMR = new

            # Implement "S__VS"
            # Regular pattern of S__VS instructions
            SVS_pattern = r".*S(EQ|NE|GT|LT|GE|LE){1}VS.*"
            if re.match(SVS_pattern, ins):
                ins_split = ins.split()
                vec1 = self.RFs["VRF"].Read(int(ins_split[1].split("VR")[1]))
                vec2 = self.RFs["SRF"].Read(int(ins_split[2].split("SR")[1]))[0]
                # new is for new value of VMR
                new = [0x1 for e in range(64)]

                def compare(OP, v1, v2):
                    if OP == "SEQVS":
                        return v1 == v2
                    if OP == "SNEVS":
                        return v1 != v2
                    if OP == "SGTVS":
                        return v1 > v2
                    if OP == "SLTVS":
                        return v1 < v2
                    if OP == "SGEVS":
                        return v1 >= v2
                    if OP == "SLEVS":
                        return v1 <= v2

                # Evaluate the comparison
                for i in range(len(vec1)):
                    if compare(ins_split[0], vec1[i], vec2):
                        new[i] = 1
                    else:
                        new[i] = 0

                # Write back to VMR
                self.VMR = new

            ##############End VMR operations###################

            ###############Start Vector operations#############
            # Implement ADDVV
            if "ADDVV" in ins:
                # ADD the vector values up
                # add up operand 2 and operand 3, store result to operand1
                ins_split = ins.split()
                vec1 = self.RFs["VRF"].Read(int(ins_split[2].split("VR")[1]))
                vec2 = self.RFs["VRF"].Read(int(ins_split[3].split("VR")[1]))
                self.RFs["VRF"].Write(
                    int(ins_split[1].split("VR")[1]),
                    [vec1[i] + vec2[i] for i in range(len(vec1))],
                )

            # Implement ADDVS
            if "ADDVS" in ins:
                ins_split = ins.split()
                vec = self.RFs["VRF"].Read(int(ins_split[2].split("VR")[1]))
                add_num = self.RFs["SRF"].Read(int(ins_split[3].split("SR")[1]))[0]
                for i in range(len(vec)):
                    vec[i] += add_num
                self.RFs["VRF"].Write(int(ins_split[1].split("VR")[1]), vec)

            ######################End vector operations#################

            ###############Start Vector Length Register Operations#############
            # Implement MTCL instruction
            if "MTCL" in ins:
                # Move the contents of the Scalar Register SR1 into the Vector Length Register.
                reg_num = int(ins_split[1].split("SR")[1])
                new_num = self.RFs["SRF"].Read(reg_num)[0]
                self.VLR.Write(0, [new_num])

            # Implement MFCL instruction
            if "MFCL" in ins:
                # Move the contents of the Vector Length Register into the Scalar Register SR1.
                self.RFs["SRF"].Write(
                    int(ins_split[1].split("SR")[1]), self.VLR.Read(0)
                )

            ###############End Vector Length Register Operations###############

            ###############Start Scalar Operations###############
            # Implement ADD instruction
            if "ADD " in ins:
                # Parse number of register
                reg_num1 = int(ins_split[1].split("SR")[1])
                reg_num2 = int(ins_split[2].split("SR")[1])
                reg_num3 = int(ins_split[3].split("SR")[1])
                self.RFs["SRF"].Write(
                    reg_num1,
                    [
                        self.RFs["SRF"].Read(reg_num2)[0]
                        + self.RFs["SRF"].Read(reg_num3)[0]
                    ],
                )

            # Implement SUB instruction
            if "SUB " in ins:
                reg_num1 = int(ins_split[1].split("SR")[1])
                reg_num2 = int(ins_split[2].split("SR")[1])
                reg_num3 = int(ins_split[3].split("SR")[1])
                self.RFs["SRF"].Write(
                    reg_num1,
                    [
                        self.RFs["SRF"].Read(reg_num2)[0]
                        - self.RFs["SRF"].Read(reg_num3)[0]
                    ],
                )

            # Implement AND OR XOR instructions
            if "AND" in ins or "OR" in ins or "XOR" in ins:
                reg_num1 = int(ins_split[1].split("SR")[1])
                reg_num2 = int(ins_split[2].split("SR")[1])
                reg_num3 = int(ins_split[3].split("SR")[1])

                if "OR" in ins:
                    target_num = [
                        self.RFs["SRF"].Read(reg_num2)[0]
                        | self.RFs["SRF"].Read(reg_num3)[0]
                    ]
                if "XOR" in ins:
                    target_num = [
                        self.RFs["SRF"].Read(reg_num2)[0]
                        ^ self.RFs["SRF"].Read(reg_num3)[0]
                    ]
                if "AND" in ins:
                    target_num = [
                        self.RFs["SRF"].Read(reg_num2)[0]
                        & self.RFs["SRF"].Read(reg_num3)[0]
                    ]

                self.RFs["SRF"].Write(reg_num1, target_num)


            if "SLL" in ins or "SRL" in ins:
                reg_num1 = int(ins_split[1].split("SR")[1])
                reg_num2 = int(ins_split[2].split("SR")[1])
                reg_num3 = int(ins_split[3].split("SR")[1])
            # fetch operand values and then logic shifts
                if "SLL" in ins:
                    result = (
                        self.RFs["SRF"].Read(reg_num2)[0]
                        << self.RFs["SRF"].Read(reg_num3)[0]
                    )

                if "SRL" in ins:
                    result = (
                        self.RFs["SRF"].Read(reg_num2)[0]
                        >> self.RFs["SRF"].Read(reg_num3)[0]
                    )

                self.RFs["SRF"].Write(reg_num1, [target_num])

            if "SRA" in ins:
                reg_num1 = int(ins_split[1].split("SR")[1])
                reg_num2 = int(ins_split[2].split("SR")[1])
                reg_num3 = int(ins_split[3].split("SR")[1])

                # fetch MSB
                msb=1<<31 & self.RFs["SRF"].Read(reg_num2)[0]
                # clear MSB, do shift right
                tmp=(self.RFs["SRF"].Read(reg_num2)[0] & 0x7fffffff)>> self.RFs["SRF"].Read(reg_num3)[0]
                # restore MSB then store to target
                self.RFs["SRF"].Write(reg_num1, [tmp | msb])

            ###############End Scalar Operations###############

            ###############Start Memory Access Operations######
            if "LV" == ins_split[0]:
                reg_num1 = int(ins_split[1].split("VR")[1])
                reg_num2 = int(ins_split[2].split("SR")[1])
                
                value=self.VDMEM.Read(reg_num2)
                self.RFs["VRF"].Write(reg_num1, [value])

            if "SV"  == ins_split[0]:
                reg_num1 = int(ins_split[1].split("VR")[1])
                reg_num2 = int(ins_split[2].split("SR")[1])
                
                value=self.VDMEM.Read(reg_num2)
                self.RFs["VRF"].Write(reg_num1, [value])
            
            if "LVWS"  == ins_split[0]:
                pass

            if "SVWS"  == ins_split[0]:
                reg_num1 = int(ins_split[1].split("VR")[1])
                reg_num2 = int(ins_split[2].split("SR")[1])
                
                value=self.VDMEM.Read(reg_num2)
                self.RFs["VRF"].Write(reg_num1, [value])

            if "LVI"  == ins_split[0]:
                pass

            if "SVI"  == ins_split[0]:
                reg_num1 = int(ins_split[1].split("VR")[1])
                reg_num2 = int(ins_split[2].split("SR")[1])
                
                value=self.VDMEM.Read(reg_num2)
                self.RFs["VRF"].Write(reg_num1, [value])

            if "LS" in ins:
                pass

            if "SS" in ins:
                pass

            ###############End Memory Access Operations########

            # Implement "HALT" instruction
            if ins == "HALT":
                break

            else:
                # Handle unknown instruction
                #print("Unknown instruction at line: ", PC)
                pass

            # Increase PC every time after execution
            PC += 1

    def dumpregs(self, iodir):
        for rf in self.RFs.values():
            rf.dump(iodir)


if __name__ == "__main__":
    # parse arguments for input file location
    parser = argparse.ArgumentParser(description="Vector Core Performance Model")
    parser.add_argument(
        "--iodir",
        default="",
        type=str,
        help="Path to the folder containing the input files - instructions and data.",
    )
    args = parser.parse_args()

    iodir = os.path.abspath(args.iodir)
    print("IO Directory:", iodir)

    # Parse IMEM
    imem = IMEM(iodir)
    # Parse SMEM
    sdmem = DMEM("SDMEM", iodir, 13)  # 32 KB is 2^15 bytes = 2^13 K 32-bit words.
    # Parse VMEM
    vdmem = DMEM("VDMEM", iodir, 17)  # 512 KB is 2^19 bytes = 2^17 K 32-bit words.

    # Create Vector Core
    vcore = Core(imem, sdmem, vdmem)

    # Run Core
    vcore.run()
    vcore.dumpregs(iodir)

    sdmem.dump()
    vdmem.dump()

    # THE END
